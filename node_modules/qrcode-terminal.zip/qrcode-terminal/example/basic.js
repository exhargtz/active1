var qrcode = require('../lib/main');
qrcode.generate('this is the bomb');
