let handler = async m => m.reply(`
┏━━°❀❬ *DONASI* ❭❀°━━┓
┣➥ *XL:* [6281328139682]
┣➥ *Dana:* 6281328139682
┣➥ *Gopay:* 6281328139682
┣➥ *Ovo:* 6281328139682
┃ 「 *Chat OWNER* 」
┃ > *Ingin donasi? Wa.me/6281328139682*
┗━━━━━━━━━━━━━━━━
`.trim()) // Tambah sendiri kalo mau
handler.help = ['donasi']
handler.tags = ['info']
handler.command = /^dona(te|si)$/i

module.exports = handler
