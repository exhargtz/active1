let handler = async m => m.reply(`
*METODE PEMBAYARAN*

*GOPAY*
083193767362
Alwin

*DANA* 
083166821387 
Alwin

*SHOPEEPAY* 
083166821387
Alwin

*OVO*
083193767362
Alwin
`.trim()) // Tambah sendiri kalo mau
handler.help = ['shoppay']
handler.tags = ['bisnis']
handler.command = /^(shoppay)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = true
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler
